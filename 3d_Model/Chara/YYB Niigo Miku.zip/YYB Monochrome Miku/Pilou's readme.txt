~~~~~~~~~~~~~~~English~~~~~~~~~~~~~~~

-Don't redistribute
-Don't edit/take a part or textures
-Don't claim the model as your own
-Credit YYB and Pilou la baka (if you want you can put a link to my youtube chanel or my deviant art )
-No VrChat

■Forbidden matters

•Being used to violate public and order or lacking wise and subtle judgment are forbidden
•Commercial use , Political use, Religious use, Used for forbidden works about R-18 or violence.( All forbidden ! )
•Can't be used to contempt the other countries and  Other people
•Some behaviors to confuse the original author and to other stakeholders are forbidden ( such as be used for Television、Animation production company、Magazinee . etc）
•Can't be used to belittle the original author、original Motion 

https://twitter.com/piloulabakammd
https://www.youtube.com/c/Piloulabaka
http://piloulabaka.deviantart.com/

~~~~~~~~~~~~~~~日本語~~~~~~~~~~~~~~~

-このモデルデータは再配布できません(再配布不可能)
-このモデルデータのパーツやテクスチャを一部でも別のモデルデータへ移植・材質変更・非表示での使用はできません
-このモデルの制作者を偽る行為を禁止します
-ご利用の際はクレジットにYYB & Pilou La Bakaと記載願います（必要に応じて、私のYouTubeチャンネルまたは私のDeviantArtのリンクを概要欄等に記載可能です）
-No VrChat

https://twitter.com/piloulabakammd
https://www.youtube.com/c/Piloulabaka
http://piloulabaka.deviantart.com/